package com.example.huu.orderfood.Entities

object GoiMonEntity {
    var MAGOIMON: Int = 0
    var MANV: Int = 0
    var MABAN:Int = 0
    var TINHTRANG = "false"
    var NGAYGOI = ""

}

class GoiMonEntity2(var iMaGoiMon: Int, var iMaBan: Int, var iMaNV: Int, var sTinhTrang: String, var sNgayGoi: String)
